#!/bin/bash
echo "Starting deployment setup script..."
cd /home/site/wwwroot

# Log environment information
echo "Node version: $(node -v)"
echo "NPM version: $(npm -v)"
echo "Current directory: $(pwd)"
echo "Files in directory: $(ls -la)"

# Start the server
echo "Starting server..."
export NODE_ENV=production
export PORT=8080
node server.js