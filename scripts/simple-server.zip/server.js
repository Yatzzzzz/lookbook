// Simple HTTP server for testing Azure Web App deployment
const http = require('http');
const os = require('os');

// Configuration
const port = process.env.PORT || 8080;
const hostname = '0.0.0.0';

// Create server
const server = http.createServer((req, res) => {
  // Basic HTML response
  const html = `
<!DOCTYPE html>
<html>
<head>
  <title>Azure Web App - Test Server</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 40px; line-height: 1.6; }
    h1 { color: #0078D4; }
    h2 { color: #333; margin-top: 30px; }
    pre { background-color: #f5f5f5; padding: 15px; border-radius: 5px; overflow-x: auto; }
    .container { max-width: 1200px; margin: 0 auto; }
  </style>
</head>
<body>
  <div class="container">
    <h1>Azure Web App - Server Running!</h1>
    <p>This simple test server is running successfully on Azure App Service.</p>
    
    <h2>Server Information</h2>
    <pre>
Node Version: ${process.version}
Server Uptime: ${process.uptime().toFixed(2)} seconds
Hostname: ${os.hostname()}
Platform: ${os.platform()} ${os.release()}
    </pre>
    
    <h2>Environment Variables</h2>
    <pre>
PORT: ${process.env.PORT || 'Not set'}
NODE_ENV: ${process.env.NODE_ENV || 'Not set'}
WEBSITE_HOSTNAME: ${process.env.WEBSITE_HOSTNAME || 'Not set'}
    </pre>
  </div>
</body>
</html>
  `;
  
  // Send response
  res.writeHead(200, { 'Content-Type': 'text/html' });
  res.end(html);
});

// Start server
server.listen(port, hostname, () => {
  console.log(`Server running at http://${hostname}:${port}/`);
  console.log(`Node Version: ${process.version}`);
});
